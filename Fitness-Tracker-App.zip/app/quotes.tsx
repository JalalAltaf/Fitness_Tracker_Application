import { View, Text, TouchableOpacity, ActivityIndicator, StyleSheet } from 'react-native';
import { useState } from 'react';

export default function Quotes() {
  const [quote, setQuote] = useState('');
  const [author, setAuthor] = useState('');
  const [loading, setLoading] = useState(false);

  const getQuote = async () => {
    setLoading(true);
    try {
      const res = await fetch('https://zenquotes.io/api/random');
      const data = await res.json();

      setQuote(data[0].q);
      setAuthor(data[0].a);
    } catch (error) {
      setQuote('Stay positive, work hard, make it happen 💪');
      setAuthor('');
    }
    setLoading(false);
  };

  return (
    <View style={styles.container}>

      <View style={styles.card}>
        {loading ? (
          <ActivityIndicator size="large" color="#4CAF50" />
        ) : (
          <>
            <Text style={styles.quoteText}>
              {quote || "Click below to get inspired ✨"}
            </Text>

            {author !== '' && (
              <Text style={styles.author}>— {author}</Text>
            )}
          </>
        )}
      </View>

      <TouchableOpacity style={styles.button} onPress={getQuote}>
        <Text style={styles.buttonText}>Get Motivation 🚀</Text>
      </TouchableOpacity>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f2f7f5',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20
  },

  card: {
    backgroundColor: '#fff',
    padding: 25,
    borderRadius: 15,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 5,
    marginBottom: 30
  },

  quoteText: {
    fontSize: 20,
    textAlign: 'center',
    color: '#333',
    fontStyle: 'italic'
  },

  author: {
    marginTop: 15,
    textAlign: 'right',
    fontSize: 16,
    color: '#555'
  },

  button: {
    backgroundColor: '#4c63af',
    paddingVertical: 12,
    paddingHorizontal: 25,
    borderRadius: 10
  },

  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold'
  }
});