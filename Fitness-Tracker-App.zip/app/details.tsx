import { View, Text } from 'react-native';
import { useLocalSearchParams } from 'expo-router';

export default function Detail() {
  const { name, description } = useLocalSearchParams();

  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontSize: 24 }}>{name}</Text>
      <Text style={{ marginTop: 10 }}>{description}</Text>
    </View>
  );
}