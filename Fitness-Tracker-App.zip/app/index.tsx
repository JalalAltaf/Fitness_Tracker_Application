import {View, Text, FlatList, TouchableOpacity, StyleSheet} from 'react-native';
import { useRouter } from 'expo-router';
import { useContext } from 'react';
import { ExerciseContext } from './context/ExerciseContext';

export default function Home() {
  const router = useRouter();
  const { exercises } = useContext(ExerciseContext);

  return (
    <View style={styles.container}>

      <View style={styles.buttonRow}>
        <TouchableOpacity
          style={styles.button}
          onPress={() => router.push('/add')}
        >
          <Text style={styles.buttonText}>+ Add</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.button}
          onPress={() => router.push('/quotes')}
        >
          <Text style={styles.buttonText}>Quotes ✨</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={exercises}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ marginTop: 20 }}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.card}
            onPress={() =>
              router.push({
                pathname: '/details',
                params: item
              })
            }
          >
            <Text style={styles.cardTitle}>{item.name}</Text>
            <Text style={styles.cardDesc}>{item.description}</Text>
          </TouchableOpacity>
        )}
      />

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f2f7f5',
    padding: 20
  },

  title: {
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    color: '#333'
  },

  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between'
  },

  button: {
    backgroundColor: '#4c63af',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 10
  },

  buttonText: {
    color: '#fff',
    fontWeight: 'bold'
  },

  card: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4
  },

  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#222'
  },

  cardDesc: {
    marginTop: 5,
    color: '#555'
  }
});