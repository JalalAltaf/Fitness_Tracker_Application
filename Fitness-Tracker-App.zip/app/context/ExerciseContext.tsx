import { createContext, useState } from 'react';

export const ExerciseContext = createContext<any>(null);

export const ExerciseProvider = ({ children }: any) => {
  const [exercises, setExercises] = useState([
    { id: '1', name: 'Chin Ups', description: 'Upper body' },
    { id: '2', name: 'Squats', description: 'Leg exercise' }
  ]);

  return (
    <ExerciseContext.Provider value={{ exercises, setExercises }}>
      {children}
    </ExerciseContext.Provider>
  );
};