import { Stack } from 'expo-router';
import { ExerciseProvider } from './context/ExerciseContext';

export default function Layout() {
  return (
    <ExerciseProvider>
      <Stack>
        <Stack.Screen
          name="index"
          options={{ title: '💪 Fitness Tracker',  headerTitleAlign: 'center' }}
        />
      </Stack>
    </ExerciseProvider>
  );
}