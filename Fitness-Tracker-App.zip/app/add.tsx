import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ScrollView
} from 'react-native';
import { useState, useContext } from 'react';
import { useRouter } from 'expo-router';
import { ExerciseContext } from './context/ExerciseContext';

export default function Add() {
  const router = useRouter();
  const { exercises, setExercises } = useContext(ExerciseContext);

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');

  const handleAdd = () => {
    if (!name || !description) return;

    const newExercise = {
      id: Date.now().toString(),
      name,
      description
    };

    setExercises([...exercises, newExercise]);
    router.back();
  };

  return (
  <KeyboardAvoidingView
    style={{ flex: 1 }}
    behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
  >
    <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
      <View style={styles.container}>

        <Text style={styles.title}>➕ Add Exercise</Text>

        <View style={styles.card}>
          
          <Text style={styles.label}>Exercise Name</Text>
          <TextInput
            placeholder="e.g. Push Ups"
            value={name}
            onChangeText={setName}
            style={styles.input}
          />

          <Text style={styles.label}>Description</Text>
          <TextInput
            placeholder="Short description"
            value={description}
            onChangeText={setDescription}
            style={[styles.input, { height: 80 }]}
            multiline
          />

          <TouchableOpacity style={styles.button} onPress={handleAdd}>
            <Text style={styles.buttonText}>Save Exercise 💾</Text>
          </TouchableOpacity>

        </View>
      </View>
    </ScrollView>
  </KeyboardAvoidingView>
);
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f2f7f5',
    padding: 20,
    justifyContent: 'center'
  },

  title: {
    fontSize: 26,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    color: '#333'
  },

  card: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 15,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5
  },

  label: {
    fontSize: 14,
    marginBottom: 5,
    color: '#555'
  },

  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 10,
    padding: 10,
    marginBottom: 15
  },

  button: {
    backgroundColor: '#4c63af',
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: 'center'
  },

  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16
  }
});